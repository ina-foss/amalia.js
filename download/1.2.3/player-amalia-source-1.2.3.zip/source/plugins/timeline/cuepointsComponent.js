/*
 * Copyright (c) 2015 Institut National de l'Audiovisuel, INA
 * 
 * This file is part of amalia.js
 * 
 * amalia.js is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Redistributions of source code, javascript and css minified versions must
 * retain the above copyright notice, this list of conditions and the following
 * disclaimer.
 * 
 * Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 * 
 * You should have received a copy of the GNU General Public License along with
 * amalia.js. If not, see <http://www.gnu.org/licenses/>
 * 
 * amalia.js is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 */
/**
 * In charge to handle cue point component
 * @class CuepointsComponent
 * @namespace fr.ina.amalia.player.plugins.timeline
 * @module plugin
 * @submodule plugin-timeline
 * @constructor
 * @extends fr.ina.amalia.player.plugins.timeline.BaseComponent
 * @param {Object} settings
 * @param {Object} container
 */
fr.ina.amalia.player.plugins.timeline.BaseComponent.extend("fr.ina.amalia.player.plugins.timeline.CuepointsComponent", {
    ComponentClassCss : "cuepoints-component",
    ComponentModuleClassCss : "module-cuepoints",
    eventTypes : {
        CLICK : "fr.ina.amalia.player.plugins.timeline.CuepointsComponent.event.click"
    }
}, {
    /**
     * In charge to initialize cue point component
     * @method initialize
     */
    initialize : function()
    {
        this._super();
        this.mainContainer.on('click', '.cuepoint', {
            self : this
        }, this.onClickAtCuepoint);
    },
    /**
     * In charge to crate the cue point
     * @param {Number} tc time code
     * @param {Number} percentPos
     * @param {String} title
     * @param {Number} level
     * @return {Object} element
     */
    createCuePointElement : function(tc, percentPos, title, level)
    {
        return $('<i>', {
            class : 'item cuepoint fa fa-' + this.settings.icon,
            style : 'left: ' + percentPos + '%; color:' + this.settings.color + ';',
            title : title,
            'data-tc' : tc,
            'data-tclevel' : level
        });
    },
    /**
     * In charge to add item
     * @param {Object} data
     */
    addItem : function(data)
    {
        if (data.hasOwnProperty('tc'))
        {
            var tc = parseFloat(data.tc); // item tc
            var gtc = this.tcout - this.tcin; // global tc
            var percentPos = ((tc - this.tcin) * 100) / gtc;
            var lineContent = this.mainContainer.find('.line-content').first();
            var title = (data.hasOwnProperty('label') === true && data.label !== '' && data.label !== null) ? data.label : 'Tc: ' + fr.ina.amalia.player.helpers.UtilitiesHelper.formatTime(tc, 25, 'ms');
            if (tc >= this.tcin && tc <= this.tcout)
            {
                lineContent.append(this.createCuePointElement(tc, percentPos, title, data.tclevel));
                if (this.logger !== null)
                {
                    this.logger.trace(this.Class.fullName, "addItem tcin: " + this.tcin + " tcout: " + this.tcout + " tc:" + tc + " percentPos:" + percentPos);
                }
            }
        }
    },
    /**
     * In charge to remove items
     */
    removeItems : function()
    {
        this.mainContainer.find('.line-content .cuepoint').remove();
    },
    /** events* */
    /**
     * Fired on click event at the cue point
     * @method onClickAtSegment
     * @param {Object} event
     * @event fr.ina.amalia.player.components.CuepointsComponent.eventTypes.CLICK
     */
    onClickAtCuepoint : function(event)
    {
        var currentTarget = $(event.currentTarget);
        var tc = parseFloat(currentTarget.data('tc'));
        event.data.self.mainContainer.trigger(event.data.self.Class.eventTypes.CLICK, {
            tc : tc
        });
        if (event.data.self.logger !== null)
        {
            event.data.self.logger.trace(event.data.self.Class.fullName, "onClickAtCuepoint tc:" + tc);
        }
    }
});
