/*
 * Copyright (c) 2015 Institut National de l'Audiovisuel, INA
 * 
 * This file is part of amalia.js
 * 
 * amalia.js is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Redistributions of source code, javascript and css minified versions must
 * retain the above copyright notice, this list of conditions and the following
 * disclaimer.
 * 
 * Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 * 
 * You should have received a copy of the GNU General Public License along with
 * amalia.js. If not, see <http://www.gnu.org/licenses/>
 * 
 * amalia.js is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 */
/**
 * In charge of the overlay plugin
 * @class OverlayPlugin
 * @namespace fr.ina.amalia.player.plugins.overlay
 * @module plugin
 * @submodule plugin-overlay
 * @constructor
 * @extends fr.ina.amalia.player.plugins.PluginBase
 * @param {Object} settings
 * @param {Object} container
 */
fr.ina.amalia.player.plugins.PluginBase.extend("fr.ina.amalia.player.plugins.OverlayPlugin", {
    classCss : "inaplayerhtml5-plugin plugin-overlay",
    eventTypes : {
        CLICK : "fr.ina.amalia.player.plugins.OverlayPlugin.eventTypes.CLICK"
    }
}, {
    /**
     * Instance of spatial data parser
     * @property spatialsDataParser
     * @type {Object}
     * @default null
     */
    spatialsDataParser : null,
    /**
     * Parsed spatial data
     * @property spatialsData
     * @type {Object}
     * @default null
     */
    spatialsData : null,
    /**
     * Main container
     * @property container
     * @type {Object}
     * @default null
     */
    container : null,
    /**
     * Instance of raphelsjs
     * @property canvas
     * @type {Object}
     * @default null
     */
    canvas : null,
    /**
     * Initialize plugin and create container for this plugin
     * @method initializeOnLoadStart
     */
    initialize : function()
    {
        this.settings = $.extend({
            offsetTime : 1,
            callbacks : {}
        }, this.settings || {});
        this.container = $('<div>', {
            'class' : this.Class.classCss
        });
        this.pluginContainer.append(this.container);
        this.canvas = null;
        // initialisation
        this.spatialsData = null;
        this.definePlayerListeners();
    },
    /**
     * Fired on load start event
     * @method initializeOnLoadStart
     */
    initializeOnLoadStart : function()
    {
        this.updateMetadata(this.settings.metadataId, 0, this.mediaPlayer.getDuration());
        this.pluginContainer.append(this.container);
        this.createCanvas();
        this.createContextMenuOption();
    },
    /**
     * Set player events listener on the player
     * @method defineListeners
     */
    definePlayerListeners : function()
    {
        var player = this.mediaPlayer.getMediaPlayer();
        // Player events
        // L'événement sera déclenché une seul fois.
        player.one(fr.ina.amalia.player.PlayerEventType.PLUGIN_READY, {
            self : this
        }, this.onFirstTimechange);
        player.on(fr.ina.amalia.player.PlayerEventType.ENDEN, {
            self : this
        }, this.onEnd);
        player.on(fr.ina.amalia.player.PlayerEventType.TIME_CHANGE, {
            self : this
        }, this.onTimeupdate);
        player.on(fr.ina.amalia.player.PlayerEventType.SEEK, {
            self : this
        }, this.onSeek);
        // call function 200 ms after resize is complete.
        $(window).on('resize', {
            self : this
        }, this.onWindowResize);
        if (this.logger !== null)
        {
            this.logger.trace(this.Class.fullName, "definePlayerListeners");
        }
    },
    /**
     * Create context menu option
     * @method createContextMenuOption
     */
    createContextMenuOption : function()
    {
        var item = this.mediaPlayer.addMenuItemWithLink(fr.ina.amalia.player.PlayerMessage.PLUGIN_OVERLAY_CONTEXT_MENU_ENABLED_DISABLED_PLUGIN, "#", "presentation");
        if (typeof item === "object")
        {
            $(item).on('click', {
                self : this
            }, function(e)
            {
                e.preventDefault();
                e.data.self.changeDisplayState();
            });
        }
    },
    /**
     * In charge to toggle display container
     * @method changeDisplayState
     */
    changeDisplayState : function()
    {
        if (this.container.is(':visible'))
        {
            this.container.hide();
        }
        else
        {
            this.container.show();
        }
    },
    /**
     * In charge to get metadata by id,tcin and tcout
     * @param {String} metadataId
     * @param {Number} tcin
     * @param {Number} tcout
     */
    updateMetadata : function(metadataId, tcin, tcout)
    {
        var data = this.mediaPlayer.getMetadataWithRange(metadataId, tcin, tcout);
        this.spatialsDataParser = new fr.ina.amalia.player.plugins.overlay.SpatialsDataParser(this.settings, data);
        this.spatialsData = this.spatialsDataParser.getData();
        if (this.logger !== null)
        {
            this.logger.trace(this.Class.fullName, "updateMetadata metadataId: " + metadataId + " tcin :" + tcin + " tcout:" + tcout);
            this.logger.info(this.spatialsData);
        }
    },
    /**
     * In charge to update current time position
     * @method updatePos
     * @param {Number} currentTime
     */
    updatePos : function(currentTime)
    {
        if (typeof this.spatialsData !== "undefined" && this.spatialsData !== null && typeof this.spatialsData === "object" && this.spatialsData.length > 0)
        {
            currentTime = parseFloat(currentTime);
            var displayData = this.getDisplayItems(currentTime);
            if (displayData.length > 0)
            {
                this.createObject(displayData);
            }
        }
    },
    /**
     * Return display items
     * @method getDisplayItems
     * @param {Number} currentTime
     * @return {Array}
     */
    getDisplayItems : function(currentTime)
    {
        var item = null;
        var spatialsData = this.spatialsData;
        var displayData = [];
        for (var i = 0; i < this.spatialsData.length; i++)
        {
            item = this.spatialsData[i];
            if (typeof item === "object" && item.hasOwnProperty('tcin') && currentTime >= parseFloat(item.tcin) && currentTime <= parseFloat(item.tcin) + this.settings.offsetTime)
            {
                displayData.push(item);
                spatialsData.splice(i, 1);
            }
        }
        this.spatialsData = spatialsData;
        return displayData;
    },
    /**
     * In charge to create canvas
     * @method createCanvas
     */
    createCanvas : function()
    {
        var videoSize = this.getVideoSize();
        var width = videoSize.w;
        var height = videoSize.h;
        this.canvas = new Raphael(this.container.get(0), width, height);
        this.canvas.canvas.className.baseVal = "overlay-canvas";
        this.updateCanvasPosition();
        // Add event to d'événement sur les obejcts du canvas
        this.container.on(fr.ina.amalia.player.plugins.overlay.DrawBase.eventTypes.CLICK, {
            self : this
        }, this.onClickAtObject);
        if (this.logger !== null)
        {
            this.logger.trace(this.Class.fullName, "CreateCanvas width:" + width + " height: " + height);
        }
    },
    /**
     * Return Video size
     * @method getVideoSize
     */
    getVideoSize : function()
    {
        var player = this.mediaPlayer.getMediaPlayer();
        var videoHeight = player.get(0).videoHeight;
        var videoWidth = player.get(0).videoWidth;
        var widthRatio = player.width() / videoWidth;
        var heightRatio = player.height() / videoHeight;
        var ratio = Math.min(widthRatio, heightRatio);
        return {
            w : ratio * videoWidth,
            h : ratio * videoHeight
        };
    },
    /**
     * In charge to update canvas position
     * @method updateCanvasPosition
     */
    updateCanvasPosition : function()
    {
        var videoSize = this.getVideoSize();
        this.container.find('.overlay-canvas').css({
            'left' : (this.container.width() - videoSize.w) / 2,
            'top' : (this.container.height() - videoSize.h) / 2
        });
    },
    /**
     * In charge to create canvas object
     * @method createObject
     * @param {Object} data
     */
    createObject : function(data)
    {
        if (data !== null && typeof data !== "undefined")
        {
            var settings = $.extend({
                canvas : this.canvas,
                container : this.container,
                debug : this.settings.debug
            }, this.settings.parameters || {});
            var track = null;
            var object = null;
            if (typeof data === "object" && data.length > 0)
            {
                for (var i = 0; i < data.length; ++i)
                {
                    track = data[i];
                    if (track.hasOwnProperty('type'))
                    {
                        if (track.type === "rect")
                        {
                            object = new fr.ina.amalia.player.plugins.overlay.DrawRect(settings, this.mediaPlayer, data[i]);
                        }
                        else if (track.type === "ellipse")
                        {
                            object = new fr.ina.amalia.player.plugins.overlay.DrawEllipse(settings, this.mediaPlayer, data[i]);
                        }
                        else
                        {
                            if (this.logger !== null)
                            {
                                this.logger.warn(this.Class.fullName + ": L'objet ne peut pas être interpreté.");
                            }
                        }
                    }
                }
            }
        }
        else
        {
            this.logger.error("Error to create object");
            this.logger.error(data);
        }
    },
    /**
     * In charge to clear canvas
     * @method clearCanvas
     */
    clearCanvas : function()
    {
        this.canvas.clear();
        this.spatialsData = this.spatialsDataParser.getData();
        if (this.logger !== null)
        {
            this.logger.trace(this.Class.fullName, "clearCanvas : " + this.spatialsData.length);
        }
    },
    // /**Player events**/
    /**
     * Fired when windows resize event and call clear the canvas
     * @method onWindowResize
     * @param {Object} event
     */
    onWindowResize : function(event)
    {
        var videoSize = event.data.self.getVideoSize();
        var width = videoSize.w;
        var height = videoSize.h;
        if (this.canvas !== null)
        {
            event.data.self.clearCanvas();
            event.data.self.canvas.setSize(width, height);
            event.data.self.updateCanvasPosition();
        }
        if (event.data.self.logger !== null)
        {
            event.data.self.logger.trace(event.data.self.Class.fullName, "onWindowResize W: " + width + " H:" + height);
        }
    },
    /**
     * Fired on first time change event
     * @method onFirstTimechange
     * @param {Object} event
     */
    onFirstTimechange : function(event)
    {
        event.data.self.initializeOnLoadStart();
        if (event.data.self.logger !== null)
        {
            event.data.self.logger.trace(event.data.self.Class.fullName, "timechange");
        }
    },
    /**
     * Fired on end event
     * @method onEnd
     * @param {Object} event
     */
    onEnd : function(event)
    {
        event.data.self.clearCanvas();
    },
    /**
     * Fired on time change event to clear canvas
     * @method onTimeupdate
     * @param {Object} event
     * @param {Object} data
     */
    onTimeupdate : function(event, data)
    {
        event.data.self.updatePos(parseFloat(data.currentTime));
    },
    /**
     * Fired on seek event to clear canvas
     * @method onSeek
     * @param {Object} event
     */
    onSeek : function(event)
    {
        event.data.self.clearCanvas();
    },
    /**
     * Fired on click event
     * @method onClickAtObject
     * @param {Object} event
     * @param {Object} data
     */
    onClickAtObject : function(event, data)
    {
        if (typeof event.data.self.settings.parameters.callbacks.click !== "undefined")
        {
            try
            {
                /* jslint evil: true */
                eval(event.data.self.settings.parameters.callbacks.click + '(data)');
            }
            catch (e)
            {
                if (event.data.self.logger !== null)
                {
                    event.data.self.logger.warn("Send callback failed.");
                }
            }
        }
        if (event.data.self.logger !== null)
        {
            event.data.self.logger.info(event.data.self.Class.fullName, "onClickAtObject");
            event.data.self.logger.warn(event.data);
            event.data.self.logger.warn(data);
        }
    }

});
