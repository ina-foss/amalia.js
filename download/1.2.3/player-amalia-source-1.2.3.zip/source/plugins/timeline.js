/*
 * Copyright (c) 2015 Institut National de l'Audiovisuel, INA
 * 
 * This file is part of amalia.js
 * 
 * amalia.js is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Redistributions of source code, javascript and css minified versions must
 * retain the above copyright notice, this list of conditions and the following
 * disclaimer.
 * 
 * Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 * 
 * You should have received a copy of the GNU General Public License along with
 * amalia.js. If not, see <http://www.gnu.org/licenses/>
 * 
 * amalia.js is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 */
/**
 * In charge to timeline plugin for visualize the keyframes with cue point,
 * segment,image and histogram components.
 * @class TimelinePlugin
 * @namespace fr.ina.amalia.player.plugins.timeline
 * @module plugin
 * @submodule plugin-timeline
 * @constructor
 * @extends fr.ina.amalia.player.plugins.PluginBase
 * @param {Object} settings
 * @param {Object} container
 */
fr.ina.amalia.player.plugins.PluginBase.extend( "fr.ina.amalia.player.plugins.TimelinePlugin",{
    classCss : "inaplayerhtml5-plugin plugin-timeline",
    style : "",
    componentDefaultHeight : 110,
    eventTypes :
        {
            TIME_CHANGE : "fr.ina.amalia.player.plugins.timeline.TIME_CHANGE"
        }

},
{
    /**
     * Dom element for time cursor
     * @property timeCursor
     * @type {Object}
     */
    timeCursor : null,
    /**
     * Main time cursor
     * @property timeProgressContainer
     * @type {Object}
     */
    timeProgressContainer : null,
    /**
     * time axe cursor component container
     * @property timeAxisComponentContainer
     * @type {Object}
     */
    timeAxisComponentContainer : null,
    /**
     * Instance de la classe TimeAxisComponent.
     * @property timeAxisComponent
     * @type {Object} fr.ina.amalia.player.plugins.timeline.TimeAxisComponent
     * @default null
     */
    timeAxisComponent : null,
    /**
     * Contains all the components
     * @property componentsContainer
     * @type {Object}
     */
    componentsContainer : null,
    /**
     * Nav bar container
     * @property navBarContainer
     * @type {Object}
     */
    navBarContainer : null,
    /**
     * list of zoom range
     * @property navBarContainer
     * @type {Object}
     */
    zoomRangeLevels : null,
    /**
     * zoom level
     * @property navBarContainer
     * @type {Object}
     */
    zoomLevel : 0,
    /**
     * Number of line to be displayed
     * @property displayLinesNb
     * @type {Object}
     */
    displayLinesNb : 0,
    /**
     * list of components
     * @property listOfComponents
     * @default []
     */
    listOfComponents : [
    ],
    /**
     * Start time code
     * @property tcin
     * @default 0
     */
    tcin : 0,
    /**
     * End time code
     * @property tcout
     * @default 0
     */
    tcout : 0,
    /**
     * Start zoom tim ecode
     * @property zTcin
     * @default 0
     */
    zTcin : 0,
    /**
     * End zoom time code
     * @property zTcout
     * @default 0
     */
    zTcout : 0,
    /**
     * Default height of time axe
     * @property timeAxeHeight
     * @default 150
     */
    timeAxeHeight : 150,
    /**
     * Tool tip configuration
     * @property tooltipConfiguration
     * @default 150
     */
    tooltipConfiguration : {
        position : {
            my : "center bottom-20",
            at : "center top",
            delay : 3000,
            using : function(position,feedback) {
                $( this ).css( position );
                $( "<div>" )
                    .addClass( "inaplayerhtml5-arrow" )
                    .addClass( feedback.vertical )
                    .addClass( feedback.horizontal )
                    .appendTo( this );
            }
        },
        content : function()
        {
            var element = $( this );
            var title = element.attr( 'title' );
            if (element.is( "[data-src]" ))
            {
                var src = element.attr( 'data-src' );
                return "<img class='image' alt='" + title + "' src='" + src + "' />";
            }
            else
            {
                title = title.replace( /(?:\r\n|\r|\n)/g,'<br />' );
                return "<p>" + title + "</p>";
            }
        }
    },
    /**
     * Instance of local storage
     * @property localStorageManager
     * @default null
     */
    localStorageManager : null,
    /**
     * Initialize this class with default parameters
     * @method initialize
     */
    initialize : function()
    {
        this.listOfComponents = [
        ];
        // Default configuration
        this.settings = $.extend( {
            debug : this.settings.debug,
            internalPlugin : false,
            // Line configuration
            listOfLines : {},
            // Number of line to be displayed
            displayLines : 3,
            // Default zoom level
            nbZoomLevel : 3,
            // Default zoom configuration
            zoomCoef : [
                1 / 4,
                1 / 16,
                1 / 64,
                1 / 256
            ],
            // Attribute name use for zoom
            zoomProperty : 'tclevel',
            // To enable the time axis
            timeaxis : true,
            // To enable resizable mode
            resizable : false,
            viewZoomSync : false,
            viewZoomSyncOffset : 1,
            // To enable time cursor
            timecursor : true
        },
        this.settings.parameters || {} );
        
        if (this.settings.timecursor === true)
        {
            this.createTimeCursor();
        }

        this.createTimeProgressContainer();
        this.timeAxisComponentContainer = $( '<div>',{
            class : 'timeaxis'
        } );
        this.componentsContainer = $( '<div>',{
            class : 'components',
            style : 'height:' + (this.pluginContainer.height() - this.timeAxeHeight) + 'px;'
        } );
        // jquery ui sortable
        this.componentsContainer.sortable( {
            handle : '.sort-btn'
        } );
        this.pluginContainer.append( this.timeAxisComponentContainer );
        this.pluginContainer.append( this.componentsContainer );
        this.definePlayerListeners();
        this.initializeOnLoadStart();
    },
    initializeOnLoadStart : function()
    {
        this.tcin = parseFloat( this.mediaPlayer.getTcOffset() );
        this.tcout = parseFloat( this.mediaPlayer.getDuration() );
        this.zoomRangeLevels = this.getZoomRangeLevels( this.tcout,this.settings.nbZoomLevel,this.settings.zoomCoef );
        // Enable time axe
        if (this.settings.timeaxis === true)
        {
            this.initializeTimeAxeComponent();
        }
        else
        {
            this.timeProgressContainer = null;
        }
        // Create all components
        this.initializeComponents();
        this.updateRange( this.tcin,this.tcout );
        // Instance of local storage
        this.localStorageManager = new fr.ina.amalia.player.LocalStorageManager( {} );
        // update tool tips
        this.pluginContainer.find( '.plugin-btn' ).tooltip( "option","disabled",(this.localStorageManager.hasItem( 'help-tooltip' ) === false) ? false : this.localStorageManager.getItem( 'help-tooltip' ) );
        // Enabling resize mode
        if (this.settings.resizable === true)
        {
            this.pluginContainer.resizable( {
                handles : 's',
                start : this.onResizeStart,
                resize : this.onResize
            } );
        }
        this.pluginContainer.on( fr.ina.amalia.player.plugins.components.FocusComponent.eventTypes.ZOOM_ZONE_CHANGE,{
            self : this
        },
        this.onZoomZoneChangeWithFocusComponent );
    },
    /**
     * Add player events listener
     * @method definePlayerListeners
     */
    definePlayerListeners : function()
    {
        var player = this.mediaPlayer.getMediaPlayer();
        // On time change
        player.on( fr.ina.amalia.player.PlayerEventType.TIME_CHANGE,{
            self : this
        },
        this.onTimeupdate );
        player.on( fr.ina.amalia.player.PlayerEventType.DATA_CHANGE,{
            self : this
        },
        this.onDataChange );
        player.on( fr.ina.amalia.player.PlayerEventType.ZOOM_RANGE_CHANGE,{
            self : this
        },
        this.onZoomRangeChange );
        // Add data change events
        this.pluginContainer.on( fr.ina.amalia.player.plugins.timeline.SegmentsComponent.eventTypes.DATA_CHANGE,{
            self : this
        },
        this.onSegmentDataChange );
        if (this.logger !== null) 
        {
            this.logger.trace( this.Class.fullName,"definePlayerListeners" );
        }
    },
    /**
     * Initialize time axe component
     * @method initializeTimeAxeComponent
     */
    initializeTimeAxeComponent : function()
    {
        var componentSettings = $.extend( {
            debug : this.settings.debug,
            container : this.timeAxisComponentContainer,
            duration : this.mediaPlayer.getDuration(),
            expand : this.settings.resizable,
            tcOffset : this.mediaPlayer.getTcOffset()
        },
        this.settings.timeAxisSettings || {} );
        try
        {
            this.timeAxisComponent = new fr.ina.amalia.player.plugins.timeline.TimeAxisComponent( componentSettings );
            this.timeAxisComponent.getContainer().on( fr.ina.amalia.player.plugins.timeline.TimeAxisComponent.eventTypes.RANGE_CHANGE,{
                self : this
            },
            this.onRangeChange );
            this.timeAxisComponent.getContainer().on( fr.ina.amalia.player.plugins.timeline.TimeAxisComponent.eventTypes.CHANGE_DISPLAY,{
                self : this
            },
            this.onDisplayStateChange );
            this.timeAxisComponent.getContainer().on( fr.ina.amalia.player.plugins.timeline.TimeAxisComponent.eventTypes.CHANGE_TIMEAXE_DISPLAY_STATE,{
                self : this
            },
            this.onTimeaxeDisplayStateChange );
            this.timeAxisComponent.getContainer().on( fr.ina.amalia.player.plugins.timeline.TimeAxisComponent.eventTypes.CLICK_AT_TIC,{
                self : this
            },
            this.onClickTc );
        }
        catch (e)
        {
            if (this.logger !== null)
            {
                this.logger.warn( e );
            }
            this.timeAxisComponent = null;
        }
    },
    /**
     * Initialize all line with configuration
     * @method initializeComponents
     */
    initializeComponents : function()
    {
        if (this.settings.hasOwnProperty( 'listOfLines' ) === true)
        {
            var container = null;
            var component = null;
            var listOfLines = this.settings.listOfLines;
            for (var i = 0;
                i < listOfLines.length;
                i++)
            {
                var lineSettings = listOfLines[i];
                if (lineSettings.hasOwnProperty( 'title' ) === true && lineSettings.hasOwnProperty( 'type' ) === true && lineSettings.hasOwnProperty( 'metadataId' ) === true)
                {
                    container = $( '<div>',{
                        class : "component component_line-" + (i + 1)
                    } );
                    this.componentsContainer.append( container );
                    switch (lineSettings.type) {
                        // create image component
                        case "image":
                            component = this.createImagesComponent( container,lineSettings );
                            break;
                        // create segment component
                        case "segment":
                            component = this.createSegmentsComponent( container,lineSettings );
                            break;
                        // create histogram component
                        case "histogram":
                            component = this.createHistogramComponent( container,lineSettings );
                            break;
                        default:
                            component = this.createCuepointsComponent( container,lineSettings );
                    }
                    if (component !== null)
                    {
                        component.setZoomProperty( this.settings.zoomProperty );
                        this.listOfComponents.push( component );
                    }
                    else
                    {
                        if (this.logger !== null)
                        {
                            this.logger.warn( "Error initializing the component." );
                        }
                    }
                }
                else
                {
                    if (this.logger !== null) {
                        this.logger.warn( "Error initializing the component." );
                    }
                }
            }
            this.createTimlineNavBar( listOfLines.length );
        }
        this.updateComponentsHeight();
    },
    /**
     * In charge to create cue point component
     * @method createCuepointsComponent
     * @param {String} container
     * @param {Object} settings
     */
    createCuepointsComponent : function(container,settings)
    {
        var componentSettings = $.extend( {
            debug : this.settings.debug,
            container : container,
            duration : this.mediaPlayer.getDuration()
        },
        settings || {} );
        var cuepointsComponent = null;
        try
        {
            if (componentSettings.hasOwnProperty( 'className' ) === true)
            {
                /* jslint evil: true */
                cuepointsComponent = eval( "new " + componentSettings.className + '(componentSettings)' );
            }
            else
            {
                cuepointsComponent = new fr.ina.amalia.player.plugins.timeline.CuepointsComponent( componentSettings );
            }
            cuepointsComponent.getContainer().on( fr.ina.amalia.player.plugins.timeline.CuepointsComponent.eventTypes.CLICK,{
                self : this
            },
            this.onClickTc );
            cuepointsComponent.getContainer().on( fr.ina.amalia.player.plugins.timeline.CuepointsComponent.NAV_CLICK,{
                self : this,
                component : cuepointsComponent
            },
            this.onClickNavControls );
        }
        catch (e)
        {
            if (this.logger !== null) {
                this.logger.warn( e );
            }
        }
        return cuepointsComponent;
    },
    /**
     * In charge to create segment component
     * @method createSegmentsComponent
     * @param {String} container
     * @param {Object} settings
     */
    createSegmentsComponent : function(container,settings)
    {
        var componentSettings = $.extend( {
            debug : this.settings.debug,
            container : container,
            duration : this.mediaPlayer.getDuration()
        },
        settings || {} );
        var segmentsComponent = null;
        try
        {
            if (componentSettings.hasOwnProperty( 'className' ) === true)
            {
                /* jslint evil: true */
                segmentsComponent = eval( "new " + componentSettings.className + '(componentSettings)' );
            }
            else
            {
                segmentsComponent = new fr.ina.amalia.player.plugins.timeline.SegmentsComponent( componentSettings );
            }
            segmentsComponent.getContainer().on( fr.ina.amalia.player.plugins.timeline.SegmentsComponent.eventTypes.CLICK,{
                self : this
            },
            this.onClickTc );
            segmentsComponent.getContainer().on( fr.ina.amalia.player.plugins.timeline.CuepointsComponent.NAV_CLICK,{
                self : this,
                component : segmentsComponent
            },
            this.onClickNavControls );
        }
        catch (e)
        {
            if (this.logger !== null)
            {
                this.logger.warn( e );
            }
        }
        return segmentsComponent;
    },
    /**
     * In charge to create image component
     * @method createImagesComponent
     * @param {String} container
     * @param {Object} settings
     */
    createImagesComponent : function(container,settings)
    {
        var componentSettings = $.extend( {
            debug : this.settings.debug,
            container : container,
            duration : this.mediaPlayer.getDuration()
        },
        settings || {} );
        var imagesComponent = null;
        try
        {
            if (componentSettings.hasOwnProperty( 'className' ) === true)
            {
                /* jslint evil: true */
                imagesComponent = eval( "new " + componentSettings.className + '(componentSettings)' );
            }
            else
            {
                imagesComponent = new fr.ina.amalia.player.plugins.timeline.ImagesComponent( componentSettings );
            }
            imagesComponent.getContainer().on( fr.ina.amalia.player.plugins.timeline.ImagesComponent.eventTypes.CLICK,{
                self : this
            },
            this.onClickTc );
            imagesComponent.getContainer().on( fr.ina.amalia.player.plugins.timeline.CuepointsComponent.NAV_CLICK,{
                self : this,
                component : imagesComponent
            },
            this.onClickNavControls );
        }
        catch (e)
        {
            if (this.logger !== null)
            {
                this.logger.warn( e );
            }
        }
        return imagesComponent;
    },
    /**
     * In charge to create histogram component
     * @method createHistogramComponent
     * @param {String} container
     * @param {Object} settings
     */
    createHistogramComponent : function(container,settings)
    {
        var componentSettings = $.extend( {
            debug : this.settings.debug,
            container : container,
            duration : this.mediaPlayer.getDuration(),
            tcOffset : this.mediaPlayer.getTcOffset()
        },
        settings || {} );
        var histogramComponent = null;
        try
        {
            if (componentSettings.hasOwnProperty( 'className' ) === true)
            {
                /* jslint evil: true */
                histogramComponent = eval( "new " + histogramComponent.className + '(componentSettings)' );
            }
            else
            {
                histogramComponent = new fr.ina.amalia.player.plugins.timeline.HistogramComponent( componentSettings );
            }
        }
        catch (error)
        {
            if (this.logger !== null)
            {
                this.logger.warn( error.stack );
            }
        }
        return histogramComponent;
    },
    /**
     * In charge to create time cursor container
     * @method createTimeCursor
     */
    createTimeCursor : function()
    {
        this.timeCursor = $( '<div>',{
            'class' : 'timeline-cursor'
        } );
        // Add to main container
        this.pluginContainer.append( this.timeCursor );
        if (this.logger !== null)
        {
            this.logger.trace( this.Class.fullName,"createTimeCursor" );
        }
    },
    /**
     * In charge to create time progress bar container
     * @method createTimeCursor
     */
    createTimeProgressContainer : function()
    {
        this.timeProgressContainer = $( '<div>',{
            'class' : 'timeline-progress-container'
        } );
        // Add to main container
        this.pluginContainer.append( this.timeProgressContainer );
        if (this.logger !== null) {
            this.logger.trace( this.Class.fullName,"createTimeCursor" );
        }
    },
    /**
     * In charge to create time axe navigation bar
     * @param {Numbre} nbItems
     */
    createTimlineNavBar : function(nbItems)
    {
        this.navBarContainer = $( '<div>',{
            'class' : 'module-nav-bar-container '
        } );
        var rowContainer = $( '<div>',{
            class : 'row toolsbar'
        } );
        var leftContainer = $( '<div>',{
            class : 'col-xs-3 col-md-3 col-lg-3 leftContainer'
        } );
        var middleContainer = $( '<div>',{
            class : 'col-xs-6 col-md-6 col-lg-6 middleContainer'
        } );
        var rightContainer = $( '<div>',{
            class : 'col-xs-3 col-md-3 col-lg-3 rightContainer'
        } );
        // boutons
        var scrollDownBtn = this.createButton( fr.ina.amalia.player.PlayerMessage.PLUGIN_TIMELINE_LABEL_SCROLL_DOWN,'chevron-down scroll-btn' );
        scrollDownBtn.on( 'click',{
            self : this
        },
        this.onScrollDown );
        var scrollUpBtn = this.createButton( fr.ina.amalia.player.PlayerMessage.PLUGIN_TIMELINE_LABEL_SCROLL_UP,'chevron-up scroll-btn' );
        scrollUpBtn.on( 'click',{
            self : this
        },
        this.onScrollUp );
        middleContainer.append( scrollUpBtn );
        middleContainer.append( scrollDownBtn );
        leftContainer.append( $( '<div>',{
            class : 'info',
            text : nbItems + ' ' + fr.ina.amalia.player.PlayerMessage.PLUGIN_TIMELINE_LABEL_ELEMENTS
        } ) );
        rightContainer.append( this.createDropdownMenu() );
        rowContainer.append( leftContainer );
        rowContainer.append( middleContainer );
        rowContainer.append( rightContainer );
        this.navBarContainer.append( rowContainer );
        // Add to main container
        this.pluginContainer.append( this.navBarContainer );
        //enable bottom navigation menu
        this.pluginContainer.find('.dropdown-toggle').dropdown();
        if (this.logger !== null) {
            this.logger.trace( this.Class.fullName,"createTimlineNavBar" );
        }
    },
    /**
     * Create button with tooltip
     * @method createButton
     * @param {String} name
     * @param {String} icon
     */
    createButton : function(name,icon)
    {
        return $( '<button>',{
            title : name,
            class : "plugin-btn fa fa-" + icon
        } ).tooltip( this.tooltipConfiguration );
    },
    /**
     * Create drop down menu
     * @method createDropdownMenu
     */
    createDropdownMenu : function()
    {
        var dropup = $( '<div>',{
            class : 'config-menu btn-group dropup'
        } );
        var dropupCtrl = $( '<span>',{
            class : "config-btn dropdown-toggle",
            'data-toggle' : "dropdown"
        } );
        dropupCtrl.append( $( '<span>',{
            class : "fa fa-cog"
        } ) );
        dropup.append( dropupCtrl );
        var menuItems = $( "<ul>",{
            'class' : 'config-menu-list dropdown-menu',
            "role" : "menu"
        } );
        // Item permettant de contrôler l'affichage des infobulles
        var itemHideTootips = $( '<li>',{
            text : fr.ina.amalia.player.PlayerMessage.PLUGIN_TIMELINE_LABEL_SHOW_HIDE_TOOTIP
        } ).on( 'click',{
            self : this
        },
        this.onChangeToogleStatus );
        menuItems.append( itemHideTootips );
        dropup.append( menuItems );
        return dropup;
    },
    /**
     * Update time cursor position
     * @method updateTimelinePos
     * @param {Object} currentTime
     */
    updateTimelinePos : function(currentTime)
    {
        var tc = parseFloat( currentTime ); // item tc
        var gtc = this.tcout - this.tcin; // global tc
        var percentWidth = ((tc - this.tcin) * 100) / gtc;
        
        if (currentTime > this.tcin && currentTime < this.tcout)
        {
            this.timeCursor.show();
            this.timeCursor.data( 'tc',currentTime );
            this.timeCursor.css( 'left',percentWidth + '%' );
            if (this.timeProgressContainer !== null)
            {
                this.timeProgressContainer.show();
                this.timeProgressContainer.data( 'tc',currentTime );
                this.timeProgressContainer.css( 'right',(100 - percentWidth) + '%' );
            }
        }
        else if (currentTime > this.tcin)
        {
            this.timeCursor.hide();
            if (this.timeProgressContainer !== null)
            {
                this.timeProgressContainer.css( 'right','0%' );
            }
        }
        else
        {
            this.timeCursor.hide();
            if (this.timeProgressContainer !== null)
            {
                this.timeProgressContainer.hide();
            }
        }
    },
    /**
     * Update time range
     * @param {Number} tcin
     * @param {Number} tcout
     */
    updateRange : function(tcin,tcout)
    {
        this.tcin = tcin;
        this.tcout = tcout;
        this.zoomLevel = this.getZoomRangeLevel( this.tcin,this.tcout );
        this.updateMetadata( tcin,tcout );
    },
    /**
     * Update metadata with tcin and tcout
     * @param {Number} tcin
     * @param {Number} tcout
     */
    updateMetadata : function(tcin,tcout)
    {
        var listOfObject = null;
        for (var i = 0;
            i < this.listOfComponents.length;
            i++)
        {
            var component = this.listOfComponents[i];
            component.setZoomLevel( this.zoomLevel );
            if (typeof component.setTcin === "function" && typeof component.setTcout === "function")
            {
                component.setTcin( tcin );
                component.setTcout( tcout );
                component.setZoomTc( tcin,tcout );
            }
            if (typeof component.removeItems === "function")
            {
                component.removeItems();
            }
            if (typeof component.addItems === "function" && typeof component.getMetadataId === "function")
            {
                if (typeof this.mediaPlayer.getMetadataById( component.getMetadataId() ) !== "undefined")
                {
                    listOfObject = this.mediaPlayer.getMetadataById( component.getMetadataId() )[0];
                    component.addItems( listOfObject );
                }
            }

        }
    },
    /**
     * 
     */
    updateComponentsHeight : function()
    {
        var headerAndFooterHeight = parseFloat( this.pluginContainer.find( '.timeaxis' ).height() + this.pluginContainer.find( '.module-nav-bar-container' ).height() );
        var lineHeight = parseFloat( fr.ina.amalia.player.plugins.TimelinePlugin.componentDefaultHeight );
        var offset = 2;
        this.displayLinesNb = (typeof this.settings.displayLines === "number") ? this.settings.displayLines : this.settings.listOfLines.length;
        if (this.displayLinesNb > this.settings.listOfLines.length)
        {
            this.displayLinesNb = this.settings.listOfLines.length;
        }
        offset = this.displayLinesNb * offset;
        if (this.settings.timeaxis)
        {
            this.pluginContainer.css( 'height',((this.displayLinesNb * lineHeight) + this.timeAxeHeight + this.navBarContainer.height()) + 'px' );
        }
        else
        {
            this.pluginContainer.css( 'height',((this.displayLinesNb * lineHeight) + this.navBarContainer.height()) + 'px' );
        }
        this.componentsContainer.css( 'height',(this.pluginContainer.height() - headerAndFooterHeight) + 'px' );
        var scrollBtnState = (this.componentsContainer.height() + offset >= this.componentsContainer.get( 0 ).scrollHeight);
        this.navBarContainer.find( '.scroll-btn' ).toggle( !scrollBtnState );
        if (!scrollBtnState)
        {
            this.componentsContainer.on( 'mousewheel DOMMouseScroll',{
                self : this
            },
            this.onComponentsMousewheel );
        }
    },
    /**
     * Update line height
     * @method updateComponentsLineHeight
     */
    updateComponentsLineHeight : function()
    {
        var element = this.pluginContainer;
        var headerAndFooterHeight = parseFloat( element.find( '.timeaxis' ).height() + element.find( '.module-nav-bar-container' ).height() );
        var linesOffset = 2 * element.find( '.component' ).length;
        var lineHeight = $( element ).find( '.component' ).first().height();
        element.find( '.components' ).first().css( 'height',lineHeight * element.find( '.component' ).length + linesOffset ); // 5
                                                                                                                                // offset
        element.css( "height",lineHeight * element.find( '.component' ).length + linesOffset + headerAndFooterHeight );
    },
    /**
     * Change tooltip display state
     * @param {Object} event
     */
    onChangeToogleStatus : function(event)
    {
        // get last status
        var disabled = event.data.self.pluginContainer.find( '.plugin-btn' ).tooltip( "option","disabled" );
        // setter
        event.data.self.pluginContainer.find( '.plugin-btn' ).tooltip( "option","disabled",!disabled );
        // set into local storage
        event.data.self.localStorageManager.setItem( 'help-tooltip',!disabled );
    },
    /**
     * Get all zoom range level with timecode and zoom coefficient
     * @param {Number} tc time code
     * @param {Number} nbLevel level numbre
     * @param {Object} zoomCoef
     */
    getZoomRangeLevels : function(tc,nbLevel,zoomCoef)
    {
        var zoomTcRange = [
        ];
        var zoomRange = null;
        for (var i = 0;
            i < nbLevel;
            i++)
        {
            zoomRange = {
                level : i,
                start : (i < nbLevel - 1) ? zoomCoef[i] * tc : 0,
                end : (i === 0) ? tc : zoomCoef[i - 1] * tc
            };
            zoomRange.tc = zoomRange.end - zoomRange.start;
            zoomTcRange.push( zoomRange );
        }
        return zoomTcRange;
    },
    /**
     * Get zoom range level with timecode
     * @param {Number} tcin
     * @param {Number} tcout
     */
    getZoomRangeLevel : function(tcin,tcout)
    {
        var tc = tcout - tcin;
        for (var i = 0;
            i < this.zoomRangeLevels.length;
            i++)
        {
            if (tc > this.zoomRangeLevels[i].start && tc < this.zoomRangeLevels[i].end)
            {
                return this.zoomRangeLevels[i].level;
            }
        }
        return 0;
    },
    /**
     * Fired on zomm change
     * @method updateZoomChange
     * @param {Number} zTcin
     * @param {Number} zTcout
     */
    updateZoomChange : function(zTcin,zTcout)
    {
        if ( this.zTcin  !== zTcin  ||  this.zTcout  !==  zTcout )
        {
            this.zTcin = Math.max( 0,parseFloat( zTcin ) );
            this.zTcout = Math.min( this.mediaPlayer.getDuration(),parseFloat( zTcout ) );
            this.mediaPlayer.setZoomTc( this.zTcin,this.zTcout,this.eventTag );
            // Seulement si le composant est initialisé
            if (this.timeAxisComponent !== null)
            {
                this.timeAxisComponent.setZoomTc( this.zTcin,this.zTcout );
            }
            this.updateRange( this.zTcin,this.zTcout );
            if (this.settings.timecursor === true)
            {
                this.updateTimelinePos( parseFloat( this.mediaPlayer.getCurrentTime() ) );
            }
        }
    },
    // /**Player events**/
    /**
     * Fired on time change event for update time cursor
     * @method onFirstTimechange
     * @param {Object} event
     * @param {Object} data Données renvoyer par l'événement timeupdate.
     */
    onTimeupdate : function(event,data)
    {
        if (event.data.self.settings.timecursor === true)
        {
            event.data.self.updateTimelinePos( parseFloat( data.currentTime ) );
        }
        event.data.self.pluginContainer.trigger( fr.ina.amalia.player.plugins.TimelinePlugin.eventTypes.TIME_CHANGE,{
            'currentTime' : data.currentTime
        } );
        if (event.data.self.settings.viewZoomSync === true)
        {
            if (parseFloat( data.currentTime ) > (event.data.self.zTcout - event.data.self.settings.viewZoomSyncOffset))
            {
                var range = (event.data.self.zTcout - event.data.self.zTcin);
                var zTcout = Math.min( event.data.self.mediaPlayer.getDuration(),event.data.self.zTcout + range );
                var zTcin = Math.max( 0,zTcout - range );
                event.data.self.updateZoomChange( zTcin,zTcout );
            }
        }
    },
    /**
     * Trigger on zoom range change
     * @method onRangeChange
     * @param {Object} event
     * @param {Object} data tcin/tcout
     */
    onRangeChange : function(event,data)
    {
        event.data.self.updateZoomChange( parseFloat( data.tcin ),parseFloat( data.tcout ) );
        if (event.data.self.logger !== null)
        {
            event.data.self.logger.trace( event.data.self.Class.fullName,"onRangeChange Tcin:" + data.tcin + " Tcout" + data.tcout );
        }
    },
    /**
     * Fired on click at time code
     * @param {Object} event
     * @param {Object} data
     */
    onClickTc : function(event,data)
    {
        if (data.hasOwnProperty( 'tc' ) === true)
        {
            event.data.self.mediaPlayer.setCurrentTime( parseFloat( data.tc ) );
        }
    },
    /**
     * Fired on display state change event
     * @param {Object} event
     */
    onDisplayStateChange : function(event)
    {
        for (var i = 0;
            i < event.data.self.listOfComponents.length;
            i++)
        {
            var component = event.data.self.listOfComponents[i];
            if (typeof component.changeDisplayState === "function")
            {
                component.changeDisplayState();
            }
        }
        // Permet de mettre à jour la hauteur du plugin
        if (event.data.self.settings.displayLines === false)
        {
            event.data.self.updateComponentsLineHeight();
        }
    },
    /**
     * Fired on time axe display change event
     * @param {Object} event
     * @param {Object} data
     */
    onTimeaxeDisplayStateChange : function(event,data)
    {
        if (event.data.self.timeProgressContainer !== null)
        {
            if (data.state === true)
            {
                event.data.self.timeProgressContainer.css( 'height','102px' );
            }
            else
            {
                event.data.self.timeProgressContainer.css( 'height','2px' );
            }
        }
        if (event.data.self.settings.displayLines === false)
        {
            event.data.self.updateComponentsLineHeight();
        }
        else
        {
            var element = event.data.self.pluginContainer;
            var headerAndFooterHeight = parseFloat( element.find( '.timeaxis' ).height() + element.find( '.module-nav-bar-container' ).height() );
            var linesOffset = 2 * event.data.self.displayLinesNb;
            var lineHeight = $( element ).find( '.component' ).first().height();
            var componentsHeight = lineHeight* event.data.self.displayLinesNb+linesOffset;
            element.find( '.components' ).first().css( 'height',componentsHeight );
            element.css( "height",componentsHeight  + headerAndFooterHeight );
        }
    },
    /**
     * Fired on click to nav control
     * @param {Object} event
     * @param {Object} data
     */
    onClickNavControls : function(event,data)
    {
        if (data.hasOwnProperty( 'type' ) === true)
        {
            var tc = (data.type === 'next') ? event.data.component.getNextItem( event.data.self.mediaPlayer.getCurrentTime() ) : event.data.component.getPrevItem( event.data.self.mediaPlayer.getCurrentTime() );
            event.data.self.mediaPlayer.pause();
            if (tc !== null)
            {
                event.data.self.mediaPlayer.setCurrentTime( tc );
            }
        }
    },
    /**
     * Fired on scroll up event
     * @param {Object} event
     */
    onScrollUp : function(event)
    {
        var moveHeight = event.data.self.componentsContainer.find( '.component' ).height();
        var scrollTop = event.data.self.componentsContainer.get( 0 ).scrollTop - moveHeight;
        scrollTop = Math.min( scrollTop,event.data.self.componentsContainer.get( 0 ).scrollHeight );
        event.data.self.componentsContainer.stop().animate( {
            scrollTop : scrollTop
        },
        500,'easeInOutExpo' );
    },
    /**
     * Fired on scroll down event
     * @param {Object} event
     */
    onScrollDown : function(event)
    {
        var moveHeight = event.data.self.componentsContainer.find( '.component' ).height();
        var scrollTop = event.data.self.componentsContainer.get( 0 ).scrollTop + moveHeight;
        scrollTop = Math.min( scrollTop,event.data.self.componentsContainer.get( 0 ).scrollHeight );
        event.data.self.componentsContainer.stop().animate( {
            scrollTop : scrollTop
        },
        500,'easeInOutExpo' );
    },
    /**
     * Fired on Mousewheel event
     * @param {Object} event
     */
    onComponentsMousewheel : function(event)
    {
        // permet d'empêcher le scrool de la page
        event.preventDefault();
        var delta = Math.max( -1,Math.min( 1,(event.originalEvent.wheelDelta || -event.originalEvent.detail) ) ) * 40;
        if (typeof delta === "number")
        {
            var scrollTop = event.data.self.componentsContainer.get( 0 ).scrollTop - delta;
            scrollTop = Math.min( scrollTop,event.data.self.componentsContainer.get( 0 ).scrollHeight );
            event.data.self.componentsContainer.get( 0 ).scrollTop = scrollTop;
        }
    },
    /**
     * Fired on resize start event
     * @param {Object} evnet
     * @param {Object} ui
     */
    onResizeStart : function(evnet,ui)
    {
        var element = ui.element;
        var lineHeight = $( element ).find( '.component' ).first().height();
        var linesOffset = 2 * $( element ).find( '.component' ).length;
        var headerAndFooterHeight = parseFloat( $( element ).find( '.timeaxis' ).height() + $( element ).find( '.module-nav-bar-container' ).height() );
        element.resizable( "option","minHeight",lineHeight + headerAndFooterHeight );
        element.resizable( "option","maxHeight",(lineHeight * $( element ).find( '.component' ).length - linesOffset) + headerAndFooterHeight );
    },
    /**
     * Fired on resize event
     * @param {Object} evnet
     * @param {Object} ui
     */
    onResize : function(evnet,ui)
    {
        var element = ui.element;
        var headerAndFooterHeight = parseFloat( $( element ).find( '.timeaxis' ).height() + $( element ).find( '.module-nav-bar-container' ).height() );
        $( element ).find( '.components' ).first().css( 'height',ui.size.height - headerAndFooterHeight );
    },
    /**
     * Fired on data change event
     * @param {Object} event
     */
    onDataChange : function(event)
    {
        event.data.self.updateRange( event.data.self.tcin,event.data.self.tcout );
    },
    /**
     * Fired on segment data change event
     * @param {Object} event
     * @param {Object} data
     */
    onSegmentDataChange : function(event,data)
    {
        event.data.self.mediaPlayer.getMediaPlayer().trigger( fr.ina.amalia.player.PlayerEventType.DATA_CHANGE,{
            id : data.id
        } );
    },
    /**
     * Fired on zoom zone change
     * @param {Object} event
     * @param {Object} data
     */
    onZoomZoneChangeWithFocusComponent : function(event,data)
    {
        if (Math.ceil( event.data.self.zTcin ) !== Math.ceil( data.zTcin ) || Math.ceil( event.data.self.zTcout ) !== Math.ceil( data.zTcout ))
        {
            event.data.self.updateZoomChange( data.zTcin,data.zTcout );
            if (event.data.self.logger !== null)
            {
                event.data.self.logger.trace( event.data.self.Class.fullName,"onZoomZoneChangeWithFocusComponent zTcin:" + data.zTcin + " zTcout" + data.zTcout );
            }
        }
    },
    /**
     * Fired on zoom range change
     * @param {Object} event
     * @param {Object} data
     */
    onZoomRangeChange : function(event,data)
    {
        if (data.eventTag === event.data.self.eventTag)
        {
            return;
        }
        if (Math.ceil( event.data.self.zTcin ) !== Math.ceil( data.zTcin ) || Math.ceil( event.data.self.zTcout ) !== Math.ceil( data.zTcout ))
        {
            event.data.self.updateZoomChange( data.zTcin,data.zTcout );
            if (event.data.self.logger !== null)
            {
                event.data.self.logger.trace( event.data.self.Class.fullName,"onZoomRangeChange zTcin:" + data.zTcin + " zTcout" + data.zTcout );
            }
        }
    }
} );
