/*
 * Copyright (c) 2015 Institut National de l'Audiovisuel, INA
 * 
 * This file is part of amalia.js
 * 
 * amalia.js is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Redistributions of source code, javascript and css minified versions must
 * retain the above copyright notice, this list of conditions and the following
 * disclaimer.
 * 
 * Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 * 
 * You should have received a copy of the GNU General Public License along with
 * amalia.js. If not, see <http://www.gnu.org/licenses/>
 * 
 * amalia.js is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 */
/**
 * Base class for draw component
 * @class DrawBase
 * @namespace fr.ina.amalia.player.plugins.overlay
 * @module plugin
 * @submodule plugin-overlay
 * @constructor
 * @param {Object} settings Defines the configuration of this class
 * @param {Object} mediaPlayer
 * @param {Object} data
 */
$.Class("fr.ina.amalia.player.plugins.overlay.DrawBase", {
    classCss : "draw-base",
    eventTypes : {
        CLICK : "fr.ina.amalia.player.plugins.overlay.DrawBase.eventTypes.CLICK"
    }
}, {
    /**
     * Defines configuration
     * @property settings
     * @type {Object}
     * @default {}
     */
    settings : {},
    /**
     * In charge to render messages in the web console output
     * @property logger
     * @type {Object}
     * @default null
     */
    logger : null,
    /**
     * In charge to render messages in the web console output
     * @property container
     * @type {Object}
     * @default null
     */
    container : null,
    /**
     * In charge to render messages in the web console output
     * @property mediaPlayer
     * @type {Object}
     * @default null
     */
    mediaPlayer : null,
    /**
     * Component container element
     * @property element
     * @type {Object}
     * @default null
     */
    element : null,
    /**
     * Label container element
     * @property labelElement
     * @type {Object}
     * @default null
     */
    labelElement : null,
    /**
     * Spatial data
     * @property data
     * @type {Object}
     * @default null
     */
    data : null,
    /**
     * Init
     * @constructor
     * @param {Object} settings
     * @param {Object} mediaPlayer
     * @param {Object} data
     */
    init : function(settings, mediaPlayer, data)
    {
        this.mediaPlayer = mediaPlayer;
        this.data = data;
        this.settings = $.extend({
            debug : false,
            container : null,
            canvas : null,
            demo : false,
            style : {
                'fill' : "#00CCFF",
                'strokeWidth' : 1,
                'stroke' : '#000',
                'fillOpacity' : 0.0,
                'strokeDasharray' : "- "
            }
        }, settings || {});

        this.container = this.settings.container;
        if (typeof fr.ina.amalia.player.log !== "undefined" && typeof fr.ina.amalia.player.log.LogHandler !== "undefined")
        {
            this.logger = new fr.ina.amalia.player.log.LogHandler({
                enabled : this.settings.debug
            });
        }
        if (typeof this.settings.canvas === "object" && this.data !== null)
        {
            this.initialize();
        }
        if (this.mediaPlayer !== null)
        {
            var player = this.mediaPlayer.getMediaPlayer();
            player.on(fr.ina.amalia.player.PlayerEventType.PLAYING, {
                self : this
            }, this.onPlay);
            player.on(fr.ina.amalia.player.PlayerEventType.PAUSED, {
                self : this
            }, this.onPause);
        }
    },
    /**
     * Initialize
     * @method initialize
     */
    initialize : function()
    {
        if (this.logger !== null)
        {
            this.logger.trace(this.Class.fullName, "initialize");
            this.logger.info(this.data);
        }
    },
    /**
     * Return default style component
     * @method getStyle
     * @return {Object}
     */
    getStyle : function()
    {
        return {
            'fill' : this.settings.style.fill,
            'stroke' : this.settings.style.stroke,
            'stroke-width' : this.settings.style.strokeWidth,
            'fill-opacity' : this.settings.style.fillOpacity,
            'stroke-dasharray' : this.settings.style.strokeDasharray
        };
    },
    /**
     * Fired on click event
     * @method onClick
     * @param {Object} event
     */
    onClick : function(event)
    {
        if (event.data.self.container !== null)
        {
            event.data.self.container.trigger(fr.ina.amalia.player.plugins.overlay.DrawBase.eventTypes.CLICK, {
                'tcin' : event.data.tcin,
                'tcout' : event.data.tcout,
                'data' : event.data.data
            });
        }
    },
    /**
     * Fired on play event
     * @method onPlay
     * @param {Object} event
     */
    onPlay : function(event)
    {
        if (event.data.self.element !== null)
        {
            event.data.self.element.resume();
        }
    },
    /**
     * Fired on pause event
     * @method onPause
     * @param {Object} event
     */
    onPause : function(event)
    {
        if (event.data.self.element !== null)
        {
            event.data.self.element.pause();
        }
    },
    /**
     * Fired when an animation was complete.
     * @method onEndOfAnimation
     */
    onEndOfAnimation : function()
    {
        if (this.data('demo') !== true)
        {
            this.remove();
        }
    }
});
