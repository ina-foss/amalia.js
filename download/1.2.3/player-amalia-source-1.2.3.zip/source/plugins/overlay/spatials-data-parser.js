/*
 * Copyright (c) 2015 Institut National de l'Audiovisuel, INA
 * 
 * This file is part of amalia.js
 * 
 * amalia.js is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Redistributions of source code, javascript and css minified versions must
 * retain the above copyright notice, this list of conditions and the following
 * disclaimer.
 * 
 * Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 * 
 * You should have received a copy of the GNU General Public License along with
 * amalia.js. If not, see <http://www.gnu.org/licenses/>
 * 
 * amalia.js is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 */
/**
 * Class de parser spatials data and used to draw rectangle and ellipse
 * @class SpatialsDataParser
 * @namespace fr.ina.amalia.player.plugins.overlay
 * @module plugin
 * @submodule plugin-overlay
 * @extends fr.ina.amalia.player.plugins.overlay
 */
$.Class("fr.ina.amalia.player.plugins.overlay.SpatialsDataParser", {}, {
    /**
     * Parsed data
     * @property data
     * @type {Object}
     * @default null
     */
    data : null,
    /**
     * Spatials data
     * @property spatials
     * @type {Object}
     * @default null
     */
    spatials : null,
    /**
     * Defines configuration
     * @property settings
     * @type {Object}
     * @default null
     */
    settings : {},
    /**
     * In charge to render messages in the web console output
     * @property logger
     * @type {Object}
     * @default null
     */
    logger : null,
    /**
     * In charge to inisialize this class
     * @constructor
     * @param {Object} settings
     * @param {Object} data
     */
    init : function(settings, data)
    {
        this.data = data;
        this.spatials = [];
        this.settings = $.extend({
            debug : false
        }, settings || {});
        if (typeof fr.ina.amalia.player.log !== "undefined" && typeof fr.ina.amalia.player.log.LogHandler !== "undefined")
        {
            this.logger = new fr.ina.amalia.player.log.LogHandler({
                enabled : this.settings.debug
            });
        }
        if (this.data !== null)
        {
            this.initialize();
        }
    },
    /**
     * Initialize
     * @method initialize
     */
    initialize : function()
    {
        if (this.logger !== null)
        {
            this.logger.trace(this.Class.fullName, "initialize");
        }
        this.parserMetadata();
    },
    /**
     * In charge to parse metadata data
     * @method parserMetadata
     */
    parserMetadata : function()
    {
        var item = null;
        for (var i = 0; i < this.data.length; i++)
        {
            item = this.data[i];
            if (item.hasOwnProperty('spatials') && item.spatials !== null)
            {
                this.parserSpatials(item);
            }
        }
        if (this.logger !== null)
        {
            this.logger.trace(this.Class.fullName, "parserMetadata");
            this.logger.info(this.data);
        }
    },
    /**
     * In charge to parse spatials block
     * @param {Object} item
     * @returns {undefined}
     */
    parserSpatials : function(item)
    {
        var data = item.spatials;
        var startPos = null;
        var endPos = null;
        var spatial = null;
        // spatials/spatial
        if (data.hasOwnProperty("spatial") && typeof data.spatial === "object")
        {
            spatial = data.spatial;
            for (var i = 0; i < spatial.length; i++)
            {

                if (startPos === null)
                {
                    startPos = spatial[i];
                }
                else
                {
                    endPos = spatial[i];
                    this.addSpatial(startPos, endPos, item);
                    startPos = spatial[i];
                }
            }
        }
    },
    /**
     * In charge to add spacial data
     * @param {Number} startPos
     * @param {Number} endPos
     * @param {Object} item
     */
    addSpatial : function(startPos, endPos, item)
    {
        if (typeof startPos === "object" && typeof endPos === "object" && startPos.hasOwnProperty('tc') && endPos.hasOwnProperty('tc'))
        {
            this.spatials.push({
                start : startPos,
                end : endPos,
                type : this.getType(startPos),
                data : item.data,
                label : item.label,
                thumb : item.thumb,
                tcin : fr.ina.amalia.player.helpers.UtilitiesHelper.convertHourToSeconde(startPos.tc),
                tcout : fr.ina.amalia.player.helpers.UtilitiesHelper.convertHourToSeconde(endPos.tc)
            });
        }
        else
        {
            if (this.logger !== null)
            {
                this.logger.warn(this.Class.fullName + ": Error to add spatial");
                this.logger.warn([
                        startPos,
                        endPos
                ]);
            }
        }
    },
    /**
     * Return spatical object type
     * @param {Object} data
     * @return {String} rect/point/ellipse
     */
    getType : function(data)
    {
        if (data.hasOwnProperty("point") && data.point !== null)
        {
            return "point";
        }
        else if (data.hasOwnProperty("ellipse") && data.ellipse !== null)
        {
            return "ellipse";
        }
        else
        {
            return "rect";
        }
    },
    /**
     * Return spacial data
     * @returns {Object}
     */
    getData : function()
    {
        return $.extend(true, [], this.spatials);
    }
});
