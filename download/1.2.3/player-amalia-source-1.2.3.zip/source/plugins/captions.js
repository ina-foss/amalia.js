/*
 * Copyright (c) 2015 Institut National de l'Audiovisuel, INA
 * 
 * This file is part of amalia.js
 * 
 * amalia.js is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Redistributions of source code, javascript and css minified versions must
 * retain the above copyright notice, this list of conditions and the following
 * disclaimer.
 * 
 * Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 * 
 * You should have received a copy of the GNU General Public License along with
 * amalia.js. If not, see <http://www.gnu.org/licenses/>
 * 
 * amalia.js is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 */
/**
 * In charge to caption plugin and display sub title on the player
 * @class CaptionsPlugin
 * @namespace fr.ina.amalia.player.plugins
 * @module plugin
 * @submodule plugin-captions
 * @constructor
 * @extends fr.ina.amalia.player.plugins.captions.CaptionsBase
 * @param {Object} settings
 * @param {Object} container
 */
fr.ina.amalia.player.plugins.captions.CaptionsBase.extend("fr.ina.amalia.player.plugins.CaptionsPlugin", {
    classCss : "inaplayerhtml5-plugin plugin-caption",
    classCssFullscreenOn : "fullScreenOn",
    classCssFullscreenOff : "fullScreenOff"
}, {
    /**
     * In charge to create container for display subtitle
     * @method initialize
     */
    initialize : function()
    {
        this.container = $('<div>', {
            class : this.Class.classCss
        });
        this.container.addClass(this.Class.classCssFullscreenOff);
        this.listOfData = [];
        this.definePlayerListeners();
    },
    /**
     * Set events listener
     * @method definePlayerListeners
     */
    definePlayerListeners : function()
    {
        var player = this.mediaPlayer.getMediaPlayer();
        player.on(fr.ina.amalia.player.PlayerEventType.PLUGIN_READY, {
            self : this
        }, this.onPluginReady);
        // Player events
        player.on(fr.ina.amalia.player.PlayerEventType.TIME_CHANGE, {
            self : this
        }, this.onTimeupdate);
        //
        player.on(fr.ina.amalia.player.PlayerEventType.FULLSCREEN_CHANGE, {
            self : this
        }, this.onFullscreenModeChange);

        if (this.logger !== null)
        {
            this.logger.trace(this.Class.fullName, "definePlayerListeners");
        }
    },
    /**
     * Fired when plugin ready event
     * @param {Object} event
     * @method onPluginReady
     */
    onPluginReady : function(event)
    {
        event.data.self.initializeOnLoadStart();
    },
    /**
     * In charge to load plugin
     * @method initializeOnLoadStart
     */
    initializeOnLoadStart : function()
    {
        this.settings = $.extend({
            debug : this.settings.debug,
            framerate : '25',
            internalPlugin : false,
            metadataId : '',
            level : 2
        }, this.settings.parameters || {});
        this.updateMetadata(this.settings.metadataId, this.settings.level, 0, this.mediaPlayer.getDuration());
        this.pluginContainer.append(this.container);
    },
    /**
     * In charge to update text with current time
     * @method updatePos
     * @param {Object} currentTime
     */
    updatePos : function(currentTime)
    {
        currentTime = parseFloat(currentTime);
        var displayData = $.grep(this.listOfData, function(n)
        {
            return (currentTime >= parseFloat(n.tcin) && currentTime < parseFloat(n.tcout));
        });
        var text = "";
        var textData = null;
        for (var i = 0; i < displayData.length; i++)
        {
            textData = displayData[i];
            if (textData !== null && typeof textData !== "undefined" && textData.hasOwnProperty('text') === true)
            {
                text += textData.text.toString();
            }
        }
        if (text !== "")
        {
            this.container.html(text);
            this.container.show();
        }
        else
        {
            this.container.html("");
            this.container.hide();
        }
    },
    /**
     * Set full-screen mode
     * @method setFullscreenMode
     * @param {Boolean} state true pour le mode plein ecran
     */
    setFullscreenMode : function(state)
    {
        if (state === true)
        {
            this.container.removeClass(this.Class.classCssFullscreenOff).addClass(this.Class.classCssFullscreenOn);
        }
        else
        {
            this.container.removeClass(this.Class.classCssFullscreenOn).addClass(this.Class.classCssFullscreenOff);

        }
    },
    /**
     * Fired on full-screen mode change
     * @method onFullscreenModeChange
     * @param {Object} event
     */
    onFullscreenModeChange : function(event, data)
    {
        event.data.self.setFullscreenMode(data.inFullScreen);
    }
});
