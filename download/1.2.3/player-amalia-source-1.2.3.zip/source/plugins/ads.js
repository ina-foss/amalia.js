/*
 * Copyright (c) 2015 Institut National de l'Audiovisuel, INA
 * 
 * This file is part of amalia.js
 * 
 * amalia.js is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Redistributions of source code, javascript and css minified versions must
 * retain the above copyright notice, this list of conditions and the following
 * disclaimer.
 * 
 * Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 * 
 * You should have received a copy of the GNU General Public License along with
 * amalia.js. If not, see <http://www.gnu.org/licenses/>
 * 
 * amalia.js is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 */
/**
 * It's simple poc with google ima SDK
 * @todo
 * @class AdsPlugin
 * @namespace fr.ina.amalia.player.plugins
 * @module plugin
 * @submodule plugin-ads
 * @constructor
 * @extends fr.ina.amalia.player.plugins.PluginBase
 * @param {Object} settings
 * @param {Object} container
 */
fr.ina.amalia.player.plugins.PluginBase.extend("fr.ina.amalia.player.plugins.AdsPlugin", {
    classCss : "inaplayerhtml5-plugin plugin-ads",
    style : "position: absolute;top: 0;z-index: 100;color: red;height: inherit;width: inherit;"
}, {
    container : null,
    videoContent : null,
    adDisplayContainer : null,
    adsLoader : null,
    adsManager : null,
    intervalTimer : null,
    initialize : function()
    {
        this.videoContent = this.mediaPlayer.mediaPlayer.get(0);
        this.container = $('<div>', {
            class : this.Class.classCss,
            style : this.Class.style
        });
        this.pluginContainer.append(this.container);
        this.definePlayerListeners();
        this.container.hide();
        this.requestAds();

    },
    createAdDisplayContainer : function()
    {
        // We assume the adContainer is the DOM id of the element that will
        // house the ads.
        this.adDisplayContainer = new google.ima.AdDisplayContainer(this.container.get(0));
        this.container.find('div:first').css('width', '100%').css('height', '100%');
    },
    requestAds : function()
    {
        // Create the ad display container.
        this.createAdDisplayContainer();
        // Initialize the container. Must be done via a user action on mobile
        // devices.
        this.adDisplayContainer.initialize();
        // Create ads loader.
        this.adsLoader = new google.ima.AdsLoader(this.adDisplayContainer);
        this.adsLoader.pluginInaAds = this;

        // Listen and respond to ads loaded and error events.
        this.adsLoader.addEventListener(google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED, this.onAdsManagerLoaded, false);
        this.adsLoader.addEventListener(google.ima.AdErrorEvent.Type.AD_ERROR, this.onAdError, false);
        $(this.adsLoader).on(google.ima.AdErrorEvent.Type.AD_ERROR, {
            self : this
        }, this.onAdError);
        // Request video ads.
        var date = new Date();
        var adsRequest = new google.ima.AdsRequest();
        adsRequest.adTagUrl = "http://pubads.g.doubleclick.net/gampad/ads?sz=640x360&iu=/6062/iab_vast_samples/skippable&ciu_szs=300x250,728x90&impl=s&gdfp_req=1&env=vp&output=xml_vast2&unviewed_position_start=1&url=[referrer_url]&correlator=" + date.getTime();

        // Specify the linear and nonlinear slot sizes. This helps the SDK to
        this.adsLoader.requestAds(adsRequest);
    },
    onAdsManagerLoaded : function(adsManagerLoadedEvent)
    {
        this.pluginInaAds.container.show();
        // Get the ads manager.
        this.pluginInaAds.adsManager = adsManagerLoadedEvent.getAdsManager(this.pluginInaAds.videoContent); // should
                                                                                                            // be
                                                                                                            // set
                                                                                                            // to
                                                                                                            // the
                                                                                                            // content
                                                                                                            // video
                                                                                                            // element
        this.pluginInaAds.adsManager.pluginInaAds = this.pluginInaAds;
        // Add listeners to the required events.
        this.pluginInaAds.adsManager.addEventListener(google.ima.AdErrorEvent.Type.AD_ERROR, this.pluginInaAds.onAdError);
        this.pluginInaAds.adsManager.addEventListener(google.ima.AdEvent.Type.CONTENT_PAUSE_REQUESTED, this.pluginInaAds.onContentPauseRequested);
        this.pluginInaAds.adsManager.addEventListener(google.ima.AdEvent.Type.CONTENT_RESUME_REQUESTED, this.pluginInaAds.onContentResumeRequested);
        this.pluginInaAds.adsManager.addEventListener(google.ima.AdEvent.Type.ALL_ADS_COMPLETED, this.pluginInaAds.onAdEvent);

        // Listen to any additional events, if necessary.
        this.pluginInaAds.adsManager.addEventListener(google.ima.AdEvent.Type.LOADED, this.pluginInaAds.onAdEvent);
        this.pluginInaAds.adsManager.addEventListener(google.ima.AdEvent.Type.STARTED, this.pluginInaAds.onAdEvent);
        this.pluginInaAds.adsManager.addEventListener(google.ima.AdEvent.Type.COMPLETE, this.pluginInaAds.onAdEvent);

        try
        {
            // Initialize the ads manager. Ad rules playlist will start at this
            // time.
            this.pluginInaAds.adsManager.init('100%', '100%', google.ima.ViewMode.NORMAL);
            // Call play to start showing the ad. Single video and overlay ads
            // will
            // start at this time; the call will be ignored for ad rules.
            this.pluginInaAds.adsManager.start();
        }
        catch (adError)
        {
            // An error may be thrown if there was a problem with the VAST
            // response.
            this.pluginInaAds.videoContent.play();
        }
    },
    onAdEvent : function(adEvent)
    {
        // Retrieve the ad from the event. Some events (e.g. ALL_ADS_COMPLETED)
        // don't have ad object associated.
        var ad = adEvent.getAd();
        switch (adEvent.type)
        {
            case google.ima.AdEvent.Type.LOADED :
                // This is the first event sent for an ad - it is possible to
                // determine whether the ad is a video ad or an overlay.
                if (!ad.isLinear())
                {
                    // Position AdDisplayContainer correctly for overlay. Use
                    // ad.width and ad.height.
                }
                break;
            case google.ima.AdEvent.Type.STARTED :
                // This event indicates the ad has started - the video player
                // can adjust the UI, for example display a pause button and
                // remaining time.
                if (ad.isLinear())
                {
                    // For a linear ad, a timer can be started to poll for the
                    // remaining time.
                    var pluginInaAds = this.pluginInaAds;
                    var remainingTime = null;
                    this.pluginInaAds.intervalTimer = setInterval(function()
                    {
                        remainingTime = pluginInaAds.adsManager.getRemainingTime();
                    }, 300);
                }
                break;
            case google.ima.AdEvent.Type.COMPLETE :
                // This event indicates the ad has finished - the video player
                // can perform appropriate UI actions, such as removing the
                // timer for remaining time detection.
                if (ad.isLinear())
                {
                    clearInterval(this.pluginInaAds.intervalTimer);
                }
                break;
        }
    },
    onAdError : function(adErrorEvent)
    {
        // Handle the error logging.
        if (this.pluginInaAds.logger !== null)
        {
            this.pluginInaAds.logger.warn(this.pluginInaAds.Class.fullName + " adErrorEvent: " + adErrorEvent.getError());
        }
        this.pluginInaAds.adsManager.destroy();
        this.pluginInaAds.container.hide();
    },
    onContentPauseRequested : function()
    {
        this.pluginInaAds.container.show();
        this.pluginInaAds.videoContent.pause();
    },
    onContentResumeRequested : function()
    {
        this.pluginInaAds.container.hide();
        this.pluginInaAds.videoContent.play();
    },
    /**
     * Add player events listener
     * @method definePlayerListeners
     */
    definePlayerListeners : function()
    {
        var player = this.mediaPlayer.getMediaPlayer();
        player.on(fr.ina.amalia.player.PlayerEventType.PLAYING, {
            self : this
        }, this.onPlay);

        if (this.logger !== null)
        {
            this.logger.trace(this.Class.fullName, "definePlayerListeners");
        }
    },
    /**
     * Fired on play event
     * @param {Object} event
     */
    onPlay : function(event)
    {
        if (event.data.self.logger !== null)
        {
            event.data.self.logger.trace(event.data.self.Class.fullName, "onPlay");
        }
    }
});
