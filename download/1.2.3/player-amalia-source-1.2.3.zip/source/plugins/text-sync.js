/*
 * Copyright (c) 2015 Institut National de l'Audiovisuel, INA
 * 
 * This file is part of amalia.js
 * 
 * amalia.js is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Redistributions of source code, javascript and css minified versions must
 * retain the above copyright notice, this list of conditions and the following
 * disclaimer.
 * 
 * Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 * 
 * You should have received a copy of the GNU General Public License along with
 * amalia.js. If not, see <http://www.gnu.org/licenses/>
 * 
 * amalia.js is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 */
/**
 * In charge to text sync plugin
 * @class TextSyncPlugin
 * @namespace fr.ina.amalia.player.plugins
 * @module plugin
 * @submodule plugin-text-sync
 * @constructor
 * @extends fr.ina.amalia.player.plugins.captions.CaptionsBase
 * @param {Object} settings
 * @param {Object} container
 */
fr.ina.amalia.player.plugins.captions.CaptionsBase.extend("fr.ina.amalia.player.plugins.TextSyncPlugin", {
    classCss : "inaplayerhtml5-plugin plugin-text-sync",
    style : ""
}, {
    /**
     * List of text
     * @property listOfComponents
     * @type {Object}
     * @default []
     */
    listOfComponents : [],
    /**
     * Enable Main level
     * @property withMainLevel
     * @type {Object}
     * @default null
     */
    withMainLevel : false,
    karaoke : false,
    initialize : function()
    {
        this.container = $('<ul>', {
            class : 'media-list'
        });
        this.listOfComponents = [];
        this.listOfData = [];
        this.definePlayerListeners();

        this.settings = $.extend({
            debug : this.settings.debug,
            framerate : '25',
            internalPlugin : false,
            metadataId : '',
            level : 2,
            title : '',
            description : '',
            displayLevel : ''
        }, this.settings.parameters || {});
        this.settings.displayLevel = (this.settings.displayLevel === "") ? this.settings.level : this.settings.displayLevel;
        this.withMainLevel = (this.settings.displayLevel !== this.settings.level);
        this.karaoke = this.withMainLevel;
        this.updateMetadata(this.settings.metadataId, this.settings.level, 0, this.mediaPlayer.getDuration(), true);
        if (this.settings.title !== '')
        {
            this.createTitleBlock(this.settings.title, this.settings.description);
        }
        this.initializeComponents(this.settings.displayLevel);
        // events
        this.container.on(fr.ina.amalia.player.plugins.textSyncPlugin.Component.eventTypes.CLICK, {
            self : this
        }, this.onClickTc);

        this.pluginContainer.append(this.container);
    },
    /**
     * initialize all components
     * @param {Number} displayLevel
     */
    initializeComponents : function(displayLevel)
    {
        var component = null;
        var data = null;

        for (var i = 0; i < this.listOfData.length; i++)
        {
            data = this.listOfData[i];
            if (data.level === displayLevel)
            {
                component = this.createComponent(this.container);
                if (component !== null)
                {
                    if (typeof component.createLine === "function")
                    {
                        component.createLine(data.tcin, data.tcout, data.label, (this.withMainLevel === true) ? '' : data.text, data.thumb);
                    }

                    this.listOfComponents.push(component);
                }
                else
                {
                    if (this.logger !== null)
                    {
                        this.logger.warn("Error initializing the component.");
                    }
                }
            }
            else
            {
                if (component !== null)
                {
                    component.addText(this.createWord(data));
                }
            }
        }
        // Définie la hauteur du container
        this.container.height(parseInt(this.pluginContainer.height() - parseInt(this.pluginContainer.find(".media.header").first().height())) + "px");
    },
    /**
     * In charge to create word element
     * @param {Object} data
     */
    createWord : function(data)
    {
        return $('<span>', {
            class : 'word',
            text : data.text,
            'data-tcin' : data.tcin,
            'data-tcout' : data.tcout
        });
    },
    /**
     * In charge to create text sync component
     * @param {String} container
     * @param {Object} settings
     */
    createComponent : function(container, settings)
    {
        var component = null;
        var componentSettings = $.extend({
            debug : this.settings.debug,
            container : container
        }, settings || {});

        try
        {
            component = new fr.ina.amalia.player.plugins.textSyncPlugin.Component(componentSettings);
        }
        catch (e)
        {
            if (this.logger !== null)
            {
                this.logger.warn(e);
            }
        }
        return component;
    },
    /**
     * In charge to update positions
     * @method updatePos
     * @param {Object} currentTime
     */
    updatePos : function(currentTime)
    {
        currentTime = parseFloat(currentTime);
        // Line
        this.container.find('.line').removeClass('on');
        this.container.find('.line').filter(function(index, element)
        {
            return (currentTime >= Math.round(parseFloat($(element).attr('data-tcin'))) && currentTime < Math.round(parseFloat($(element).attr('data-tcout'))));
        }).addClass('on').each(function(index, element)
        {
            element = $(element);
            var percentWidth = 0;
            var tcin = Math.round(parseInt($(element).attr('data-tcin')));
            var tcout = Math.round(parseInt($(element).attr('data-tcout')));
            percentWidth = ((Math.round(currentTime) - tcin) * 100) / (tcout - tcin);
            element.find('.progress').show();
            element.find('.progress-bar').css('width', Math.round(percentWidth) + '%');
        });
        // Word
        if (this.karaoke === true)
        {
            this.container.find('.word').removeClass('on');
            this.container.find('.word').filter(function(index, element)
            {
                return (currentTime >= parseFloat($(element).attr('data-tcin')) && currentTime < parseFloat($(element).attr('data-tcout')));
            }).addClass('on');
        }
    },
    /**
     * In charge to create tile block
     * @param {Object} title
     * @param {Object} description
     */
    createTitleBlock : function(title, description)
    {
        var container = $('<div>', {
            class : "media header"
        });
        var containerBody = $('<div>', {
            class : "media-body resume"
        });
        var titleContainer = $('<h3>', {
            class : "media-heading",
            text : title
        });
        containerBody.append(titleContainer);
        var descriptionContaienr = $('<p>', {
            text : description
        });
        containerBody.append(descriptionContaienr);
        container.append(containerBody);
        this.pluginContainer.append(container);
    },
    /**
     * Fired on click event
     * @param {Object} event
     * @param {Object} data
     */
    onClickTc : function(event, data)
    {
        if (data.hasOwnProperty('tc') === true && data.tc !== true)
        {
            event.data.self.mediaPlayer.setCurrentTime(parseFloat(data.tc));
        }
    },
    /**
     * In charge to add events
     * @method defineListeners
     */
    definePlayerListeners : function()
    {
        var player = this.mediaPlayer.getMediaPlayer();
        player.on(fr.ina.amalia.player.PlayerEventType.TIME_CHANGE, {
            self : this
        }, this.onTimeupdate);
        player.on(fr.ina.amalia.player.PlayerEventType.SEEK, {
            self : this
        }, this.onSeek);

    },
    /**
     * In charge of seek events
     * @method onSeek
     * @param {Object} event
     * @param {Object} data
     */
    onSeek : function(event, data)
    {
        var currentTime = (parseFloat(data.currentTime));
        var offsetPosition = event.data.self.container.find('li.line').eq(0).position();
        var elementPosition = event.data.self.container.find('li.line').filter(function(index, element)
        {
            return (currentTime >= Math.round(parseFloat($(element).attr('data-tcin'))) && currentTime < Math.round(parseFloat($(element).attr('data-tcout'))));
        }).first().position();
        if (elementPosition && offsetPosition)
        {
            event.data.self.container.stop().animate({
                scrollTop : elementPosition.top - offsetPosition.top
            }, 1500, 'easeInOutExpo');
        }
    }
});
